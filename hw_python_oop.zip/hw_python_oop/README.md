# hw_python_oop
Sprint 2. Итоговый проект.
